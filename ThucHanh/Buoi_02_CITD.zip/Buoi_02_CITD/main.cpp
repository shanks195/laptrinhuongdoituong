#include <iostream>

using namespace std;
class CDiem
{
private:
    float x;
    float y;
public:
    CDiem();
    CDiem(float, float);
    CDiem(const CDiem &p);
    ~CDiem();
    friend istream& operator>>(istream &is, CDiem &p);
    friend ostream& operator<<(ostream &os, CDiem &p);
    CDiem operator=(const CDiem &);
};
class CTamGiac
{
private:
    CDiem A;
    CDiem B;
    CDiem C;
public:
    CTamGiac();
    CTamGiac(CDiem, CDiem, CDiem);
    CTamGiac(const CTamGiac &);
    ~CTamGiac();
    friend istream& operator>>(istream &is, CTamGiac &g);
    friend ostream& operator<<(ostream &os, CTamGiac &g);
    CTamGiac operator=(const CTamGiac &);
};
int main()
{
    CTamGiac g;
    CDiem a(1,2), b(3,4) , c(2,6);
    CTamGiac h(a, b, c);
    cout << "Tam giac h: \n" << h;
    CTamGiac i(h);
    cout << "\nTam giac i: \n" << i;
    return 0;
}
CDiem CDiem::operator=(const CDiem &p)
{
    x = p.x;
    y = p.y;
    return *this;
}
CTamGiac CTamGiac::operator=(const CTamGiac &g)
{
    A = g.A;
    B = g.B;
    C = g.C;
    return *this;
}
CTamGiac::CTamGiac()
{
    CDiem a, b, c;
    A = a;
    B = b;
    C = c;
}
 CTamGiac::CTamGiac(CDiem a, CDiem b , CDiem c)
 {
     A = a;
     B = b;
     C = c;
 }
CTamGiac::CTamGiac(const CTamGiac &g)
{
    A = g.A;
    B = g.B;
    C = g.C;
}
CTamGiac::~CTamGiac()
{
    cout << "\nPha huy tam giac \n";
    return;
}
CDiem::CDiem()
{
    x = 0;
    y = 0;
}
CDiem::CDiem(float h, float t)
{
    x = h;
    y = t;
}
CDiem::CDiem(const CDiem &p)
{
    x = p.x;
    y = p.y;
}
CDiem::~CDiem()
{
    cout << "\nPha huy diem\n";
    return;
}
istream& operator>>(istream &is, CTamGiac &g)
{
    cout << "Nhap A: \n";
    is >> g.A;
    cout << "Nhap B: \n";
    is >> g.B;
    cout << "Nhap C: \n";
    is >> g.C;
    return is;
}
ostream& operator<<(ostream &os, CTamGiac &g)
{
    os << "A" << g.A;
    os << "\nB" << g.B;
    os << "\nC" << g.C;
    return os;
}
istream& operator>>(istream &is, CDiem &p)
{
    cout << "x = ";
    is >> p.x;
    cout << "y = ";
    is >> p.y;
    return is;
}
ostream& operator<<(ostream &os, CDiem &p)
{
    os << "(" << p.x << "," << p.y << ")";
    return os;
}
