#include <stdio.h>
#include <conio.h>
class CPhanSo
{
private:
    int tu;
    int mau;
public:
    void Nhap();
    void Xuat();
    void RutGon();
};

int main()
{
    CPhanSo ps;
    ps.Nhap();
    ps.RutGon();
    ps.Xuat();

    return 0;
}

void CPhanSo::Nhap()
{
    printf("Nhap tu: ");
    scanf("%d", &tu);
    printf("Nhap mau: ");
    scanf("%d", &mau);
}
void CPhanSo::RutGon()
{
    //Tìm ước chung lớn nhất của tử và mẫu
    int T = tu;
    int M = mau;
    while(T * M != 0)
    {
        if(T > M)
            T = T - M;
        else
            M = M - T;
    }
    //Kết thúc vòng lặp thì (T + M) là UCLN của Tử và Mẫu
    tu = tu / (T + M);
    mau = mau / (T + M);
}
void CPhanSo::Xuat()
{
    printf("%d/%d", tu, mau);
}
