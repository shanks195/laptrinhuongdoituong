#include <stdio.h>
#include <conio.h>

class CHocSinh
{
private:
    char hoten[31];
    int toan;
    int van;
    float dtb;
public:
    void Nhap();
    void Xuat();
    void XuLy();
};

int main()
{
    CHocSinh hs;
    hs.Nhap();
    hs.XuLy();
    hs.Xuat();
    return 0;
}
void CHocSinh::Nhap()
{
    printf("Nhap ho ten: ");
    gets(hoten);
    printf("Nhap toan: ");
    scanf("%d", &toan);
    printf("Nhap van: ");
    scanf("%d", &van);
}
void CHocSinh::XuLy()
{
    dtb = (float) (toan + van) / 2;
}
void CHocSinh::Xuat()
{
    printf("Ho ten: %s", hoten);
    printf("\nToan: %d", toan);
    printf("\nVan: %d", van);
    printf("\nDTB: %f", dtb);
}
